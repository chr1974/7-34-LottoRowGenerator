-- =====================================================================
-- Add odd_count as a generated, stored column (same pattern as row_sum).
-- even_count is never stored separately since even_count = 7 - odd_count
-- always - storing both would just be redundant data that could (in
-- theory, if ever manually overridden) drift out of sync.
-- =====================================================================

ALTER TABLE lotto_combinations
ADD COLUMN odd_count TINYINT UNSIGNED
    GENERATED ALWAYS AS (
        (n1 % 2) + (n2 % 2) + (n3 % 2) + (n4 % 2) + (n5 % 2) + (n6 % 2) + (n7 % 2)
    ) STORED
    AFTER row_sum;

-- Index it, since "give me all rows with exactly N odd numbers" is a
-- natural filter you'll likely reuse.
ALTER TABLE lotto_combinations
ADD INDEX idx_odd_count (odd_count);

-- Quick checks once added:
-- SELECT odd_count, COUNT(*) FROM lotto_combinations GROUP BY odd_count ORDER BY odd_count;
-- Expect a symmetric bell shape peaking around odd_count = 3 and 4.
