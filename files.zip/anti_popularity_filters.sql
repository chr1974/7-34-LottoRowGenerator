-- =====================================================================
-- Filtering combinations by "human bias" patterns.
--
-- IMPORTANT MATH NOTE: every single row in this table has EXACTLY the
-- same probability of being drawn: 1 in 5,379,616. Nothing below changes
-- that. What these filters target is a DIFFERENT problem: humans don't
-- pick numbers randomly. People over-select certain patterns (birthdays
-- -> heavy clustering in 1-31, "lucky" consecutive runs, neat-looking
-- spreads). If you happen to win with a heavily-picked combination, you
-- are more likely to SPLIT the jackpot with other winners. Picking an
-- unpopular-but-still-uniformly-likely combination doesn't make you more
-- likely to win - it makes a win worth more, on average, if it happens.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Avoid all-low rows (birthday bias: people overload on 1-31
--    because birthdays/anniversaries only go up to 31). Numbers 32-34
--    can ONLY come from genuine random/quick-pick selection, so rows
--    containing them are statistically under-selected by humans.
-- ---------------------------------------------------------------------
SELECT n1,n2,n3,n4,n5,n6,n7, row_sum, low_count
FROM lotto_combinations
WHERE low_count <= 4          -- at least 3 numbers from the 18-34 range
  AND (n1 > 31 OR n2 > 31 OR n3 > 31 OR n4 > 31 OR n5 > 31 OR n6 > 31 OR n7 > 31)
LIMIT 20;

-- ---------------------------------------------------------------------
-- 2. Avoid heavy consecutive runs (people often pick runs like
--    4,5,6,7 thinking they "look balanced" or via quick patterns).
--    consecutive_pairs = 0 means no two numbers are adjacent at all.
-- ---------------------------------------------------------------------
SELECT n1,n2,n3,n4,n5,n6,n7, row_sum, consecutive_pairs
FROM lotto_combinations
WHERE consecutive_pairs = 0
LIMIT 20;

-- ---------------------------------------------------------------------
-- 3. Avoid "neat" sums. Humans subconsciously favor sums near the
--    middle of the visible number grid: combine with row_sum filtering
--    to avoid both the extremely common middle sums AND extremely
--    rare/recognizable extreme sums (since SOME players specifically
--    chase "all low" or "all high" patterns too).
-- ---------------------------------------------------------------------
SELECT n1,n2,n3,n4,n5,n6,n7, row_sum
FROM lotto_combinations
WHERE row_sum NOT BETWEEN 100 AND 145   -- skip the most "typical-looking" sums
  AND row_sum NOT IN (28,29,30,215,216,217) -- skip the obviously-patterned extremes
LIMIT 20;

-- ---------------------------------------------------------------------
-- 4. Avoid balanced odd/even splits (3/4 or 4/3), since these LOOK
--    "random" to humans and get picked disproportionately. An uneven
--    split (e.g. 6 odd/1 even) looks "wrong" to people so is under-picked,
--    despite being equally likely mathematically.
-- ---------------------------------------------------------------------
SELECT n1,n2,n3,n4,n5,n6,n7, row_sum, odd_count
FROM lotto_combinations
WHERE odd_count NOT IN (3,4)
LIMIT 20;

-- ---------------------------------------------------------------------
-- 5. COMBINED FILTER: stack multiple anti-popularity signals at once.
--    This narrows 5.3M rows down to a small, "statistically boring to
--    humans but mathematically identical" candidate pool.
-- ---------------------------------------------------------------------
SELECT n1,n2,n3,n4,n5,n6,n7, row_sum, odd_count, spread, consecutive_pairs, low_count
FROM lotto_combinations
WHERE low_count <= 3                         -- mostly high numbers (32-34 included)
  AND odd_count NOT IN (3,4)                  -- skip the "looks balanced" split
  AND consecutive_pairs = 0                   -- no adjacent-number runs
  AND row_sum NOT BETWEEN 100 AND 145         -- skip the most common-looking sums
ORDER BY RAND()
LIMIT 10;

-- Check how much this combined filter narrows things down:
SELECT COUNT(*) AS unpopular_candidate_count
FROM lotto_combinations
WHERE low_count <= 3
  AND odd_count NOT IN (3,4)
  AND consecutive_pairs = 0
  AND row_sum NOT BETWEEN 100 AND 145;
