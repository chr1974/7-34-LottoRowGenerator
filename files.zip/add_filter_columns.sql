-- =====================================================================
-- Add spread, consecutive_pairs, and low_count as generated, stored
-- columns, same pattern as row_sum and odd_count. high_count is never
-- stored separately since high_count = 7 - low_count always.
--
-- All three rely on n1..n7 always being in strictly ascending order,
-- which the Delphi generator guarantees by construction - this is
-- what lets consecutive_pairs and spread be simple column arithmetic
-- instead of needing to sort within each row.
-- =====================================================================

ALTER TABLE lotto_combinations
ADD COLUMN spread TINYINT UNSIGNED
    GENERATED ALWAYS AS (n7 - n1) STORED
    AFTER odd_count,

ADD COLUMN consecutive_pairs TINYINT UNSIGNED
    GENERATED ALWAYS AS (
        (n2 = n1 + 1) + (n3 = n2 + 1) + (n4 = n3 + 1) +
        (n5 = n4 + 1) + (n6 = n5 + 1) + (n7 = n6 + 1)
    ) STORED
    AFTER spread,

ADD COLUMN low_count TINYINT UNSIGNED
    GENERATED ALWAYS AS (
        (n1 <= 17) + (n2 <= 17) + (n3 <= 17) + (n4 <= 17) +
        (n5 <= 17) + (n6 <= 17) + (n7 <= 17)
    ) STORED
    AFTER consecutive_pairs;

-- Index the ones you're likely to filter or group by often.
ALTER TABLE lotto_combinations
ADD INDEX idx_spread (spread),
ADD INDEX idx_consecutive_pairs (consecutive_pairs),
ADD INDEX idx_low_count (low_count);

-- Quick sanity checks once added:
-- SELECT spread, COUNT(*) FROM lotto_combinations GROUP BY spread ORDER BY spread;
-- SELECT consecutive_pairs, COUNT(*) FROM lotto_combinations GROUP BY consecutive_pairs ORDER BY consecutive_pairs;
-- SELECT low_count, COUNT(*) FROM lotto_combinations GROUP BY low_count ORDER BY low_count;
-- Expect spread range 6-33, consecutive_pairs range 0-6, low_count range 0-7 (all symmetric bell shapes).
